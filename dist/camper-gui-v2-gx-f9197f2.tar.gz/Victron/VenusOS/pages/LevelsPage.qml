/*
** Copyright (C) 2023 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import Victron.VenusOS

SwipeViewPage {
	id: root

	// Used by StartPageConfiguration when this is the start page.
	property alias currentTabIndex: tabBar.currentIndex

	readonly property LevelsTab currentTabView: tabBar.currentIndex === 0 ? tanksTab : environmentTab

	topLeftButton: VenusOS.StatusBar_LeftButton_ControlsInactive
	fullScreenWhenIdle: true
	focusPolicy: Qt.TabFocus
	//% "Levels"
	title: qsTrId("nav_levels")
	iconSource: "qrc:/images/levels.svg"
	url: "qrc:/qt/qml/Victron/VenusOS/pages/LevelsPage.qml"

	// Gauges may overflow into previous/next pages in the SwipeView, so clip the gauge ListView
	// to the page bounds.
	clip: tanksTab.contentWidth > tanksTab.width || environmentTab.contentWidth > environmentTab.width

	onActiveFocusChanged: {
		if (root.view.focusEdgeHint === Qt.TopEdge) {
			tabBar.focus = true
		} else if (root.view.focusEdgeHint === Qt.BottomEdge) {
			tabsFocusScope.focus = true
		}
	}

	// Background behind tabs, to prevent tabs/environment flickables from showing under the tab
	// bar when they are scrolled vertically.
	Rectangle {
		anchors {
			fill: tabBar
			bottomMargin: -tabsFocusScope.anchors.topMargin
		}
		color: root.backgroundColor
		visible: Theme.screenSize === Theme.Portrait
	}

	TabBar {
		id: tabBar

		anchors {
			top: parent.top
			topMargin: Global.pageManager?.expandLayout ? -tabBar.height : 0
			horizontalCenter: parent.horizontalCenter
		}
		width: Theme.screenSize === Theme.Portrait ? parent.width - (2*Theme.geometry_page_content_horizontalMargin)
				: implicitWidth
		opacity: Global.pageManager?.interactivity === VenusOS.PageManager_InteractionMode_Interactive
				 || Global.pageManager?.interactivity === VenusOS.PageManager_InteractionMode_ExitIdleMode
				 ? 1.0
				 : 0.0

		Behavior on opacity {
			enabled: root.animationEnabled && root.isCurrentPage
			OpacityAnimator { duration: Theme.animation_page_idleOpacity_duration }
		}

		Behavior on anchors.topMargin {
			enabled: root.animationEnabled && root.isCurrentPage
			NumberAnimation { duration: Theme.animation_page_idleResize_duration; easing.type: Easing.InOutQuad }
		}

		model: [
			//% "Tanks"
			{ value: qsTrId("levels_page_tanks"), enabled: tanksTab.enabled },
			//% "Environment"
			{ value: qsTrId("levels_page_environment"), enabled: environmentTab.enabled }
		]

		// Prefer a tab that is enabled.
		currentIndex: tanksTab.enabled || !environmentTab.enabled ? 0 : 1

		KeyNavigation.down: tabsFocusScope
	}

	FocusScope {
		id: tabsFocusScope
		anchors {
			top: tabBar.bottom
			topMargin: Global.pageManager?.expandLayout
					? Theme.geometry_levelsPage_gaugesView_expanded_topMargin
					: Theme.geometry_levelsPage_gaugesView_compact_topMargin
			bottom: parent.bottom
			left: parent.left
			right: parent.right
		}
		z: -1 // allow tanks/env view to scroll beneath the tab bar

		Behavior on anchors.topMargin {
			enabled: root.animationEnabled
			NumberAnimation { duration: Theme.animation_page_idleResize_duration; easing.type: Easing.InOutQuad }
		}

		TanksTab {
			id: tanksTab

			anchors.fill: parent
			animationEnabled: root.animationEnabled
			enabled: Global.tanks.totalTankCount > 0
			visible: tabBar.currentIndex === 0
			focus: visible
		}

		EnvironmentTab {
			id: environmentTab

			anchors.fill: parent
			animationEnabled: root.animationEnabled
			enabled: Global.environmentInputs.model.count > 0
			visible: tabBar.currentIndex === 1
			focus: visible
		}
	}

	// Show gradients on the left/right edges (or top/bottom in portrait) to indicate the page bounds.
	ViewGradient {
		x: Theme.screenSize === Theme.Portrait ? 0 : -(width / 2) + (height / 2)
		y: Theme.screenSize === Theme.Portrait ? tabsFocusScope.y : 0
		rotation: Theme.screenSize === Theme.Portrait ? 180 : 90
		visible: Theme.screenSize === Theme.Portrait ? !root.currentTabView.atYBeginning : !root.currentTabView.atXBeginning
	}
	ViewGradient {
		x: Theme.screenSize === Theme.Portrait ? 0 : (width / 2) - (height / 2)
		y: Theme.screenSize === Theme.Portrait ? parent.height - height : 0
		rotation: Theme.screenSize === Theme.Portrait ? 0 : 270
		visible: Theme.screenSize === Theme.Portrait ? !root.currentTabView.atYEnd : !root.currentTabView.atXEnd
	}
}
