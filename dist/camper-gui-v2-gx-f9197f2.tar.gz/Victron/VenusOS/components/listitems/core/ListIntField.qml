/*
** Copyright (C) 2024 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import Victron.VenusOS

ListTextField {
	id: root

	property int maximumLength

	readonly property var validateIntInput: function() {
		const trimmed = secondaryText.trim()
		if (!trimmed.match(/^[0-9]+$/)) {
			return Utils.validationResult(VenusOS.InputValidation_Result_Error, CommonWords.error_nan.arg(secondaryText))
		}
		if (maximumLength > 0 && trimmed.length > maximumLength) {
			//% "Use a number with %1 digits or less."
			return Utils.validationResult(VenusOS.InputValidation_Result_Error, qsTrId("number_field_input_too_long").arg(maximumLength))
		}
		return Utils.validationResult(VenusOS.InputValidation_Result_OK)
	}

	inputMethodHints: Qt.ImhDigitsOnly
	validateInput: validateIntInput
	saveInput: function() {
		if (dataItem.uid) {
			dataItem.setValue(parseInt(secondaryText))
		}
	}
}
