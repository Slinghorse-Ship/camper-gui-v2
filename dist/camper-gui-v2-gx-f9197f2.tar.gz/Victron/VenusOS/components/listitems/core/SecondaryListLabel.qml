/*
** Copyright (C) 2024 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import Victron.VenusOS

Label {
	font.pixelSize: Theme.font_listItem_secondary_size
	color: Theme.color_listItem_secondaryText
	wrapMode: Text.Wrap
	horizontalAlignment: Text.AlignRight
	verticalAlignment: Text.AlignVCenter
}
