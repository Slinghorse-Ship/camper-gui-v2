/*
** Copyright (C) 2023 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import Victron.VenusOS

ListButton {
	id: root

	readonly property alias dataItem: dataItem
	property alias value: rangeModel.value
	property string suffix
	property int decimals
	property real from: !isNaN(dataItem.min) ? dataItem.min : 0
	property real to: !isNaN(dataItem.max) ? dataItem.max : Global.int32Max / Math.pow(10, decimals) // qml int is a signed 32 bit value
	property real stepSize: 1
	property var presets: []
	property string fromErrorText
	property string toErrorText

	property var _numberSelector

	signal selectorAccepted(newValue: var)

	secondaryText: value === undefined ? "--" : Units.formatNumber(value, decimals) + root.suffix
	interactive: (dataItem.uid === "" || dataItem.valid)

	onClicked: Global.dialogLayer.open(numberSelectorComponent, {value: value})

	RangeModel {
		id: rangeModel
		minimumValue: isNaN(root.from) ? 0 : root.from
		maximumValue: isNaN(root.to) ? 100 : root.to
		value: dataItem.valid ? dataItem.value : 0
	}

	Component {
		id: numberSelectorComponent

		NumberSelectorDialog {
			title: root.text
			titleTextFormat: root.textFormat
			suffix: root.suffix
			decimals: root.decimals
			from: root.from
			to: root.to
			stepSize: root.stepSize
			presets: root.presets
			fromErrorText: root.fromErrorText
			toErrorText: root.toErrorText

			onAccepted: {
				if (dataItem.uid.length > 0) {
					dataItem.setValue(value)
				} else {
					root.value = value
				}
				root.selectorAccepted(value)
			}
		}
	}

	VeQuickItem {
		id: dataItem
	}
}
