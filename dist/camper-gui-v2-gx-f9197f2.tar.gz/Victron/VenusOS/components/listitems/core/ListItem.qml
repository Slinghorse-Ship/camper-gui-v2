/*
** Copyright (C) 2026 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import Victron.VenusOS

/*
	A focusable list items, with a background rectangle and key navigation support.
*/
AbstractListItem {
	id: root

	readonly property real horizontalContentPadding: flat
			? Theme.geometry_listItem_flat_content_horizontalMargin
			: Theme.geometry_listItem_content_horizontalMargin

	// The default format for text in the item. Defaults to AutoText, same as for QtQuick Text.
	property int textFormat: Text.AutoText

	// If true, the default background is hidden.
	property bool flat

	// True if this item leads to a sub-page when clicked.
	property bool hasSubMenu

	// Use left/rightInset to provide a gap between the page edge and the list item. Ideally would
	// use the parent Flickable left/rightMargin to do this, but the gap changes when switching
	// between portrait/landscape, and due to QTBUG-144841, dynamic left/rightMargin changes have no
	// effect on list item geometries.
	// Use zero left/rightInset when flat=true and the background is hidden (e.g. in control cards).
	// Set bottomInset to provide the standard spacing between this item and the next one in the
	// list. This cannot be done via ListView::spacing as that spacing is shown even between non-
	// visible items.
	leftInset: flat ? 0 : Theme.geometry_page_content_horizontalMargin
	rightInset: flat ? 0 : Theme.geometry_page_content_horizontalMargin
	bottomInset: Theme.geometry_gradientList_spacing
	leftPadding: leftInset + horizontalContentPadding
	rightPadding: rightInset + horizontalContentPadding
	topPadding: topInset + Theme.geometry_listItem_content_verticalMargin
	bottomPadding: bottomInset + Theme.geometry_listItem_content_verticalMargin

	implicitWidth: effectiveVisible ? Math.max(
			implicitBackgroundWidth + leftInset + rightInset,
			implicitContentWidth + leftPadding + rightPadding) : 0
	implicitHeight: effectiveVisible ? Math.max(
			implicitBackgroundHeight + topInset + bottomInset,
			implicitContentHeight + topPadding + bottomPadding) : 0
	width: parent?.width ?? Theme.geometry_listItem_width
	spacing: Theme.geometry_listItem_content_spacing

	// By default, the item is visible if preferredVisible=true.
	effectiveVisible: preferredVisible
	visible: effectiveVisible

	// Allow item to receive focus within its focus scope.
	focus: true

	// Allow Utils.acceptsKeyNavigation() to accept moving focus to this item.
	focusPolicy: effectiveVisible ? Qt.TabFocus : Qt.NoFocus

	// Set the default font for control text.
	font.pixelSize: flat ? Theme.font_listItem_flat_primary_size_flat : Theme.font_listItem_primary_size
	font.family: Global.fontFamily

	// Provide key navigation between list items.
	KeyNavigationHighlight.active: root.activeFocus
	KeyNavigationHighlight.topMargin: topInset
	KeyNavigationHighlight.bottomMargin: bottomInset
	KeyNavigationHighlight.leftMargin: leftInset
	KeyNavigationHighlight.rightMargin: rightInset
	Keys.enabled: Global.keyNavigationEnabled

	background: ListItemBackground {
		visible: !root.flat
	}
}
