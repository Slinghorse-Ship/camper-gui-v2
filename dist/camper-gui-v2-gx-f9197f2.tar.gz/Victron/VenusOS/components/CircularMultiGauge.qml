/*
** Copyright (C) 2023 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import QtQuick.Window
import QtQuick.Controls.impl as CP
import Victron.VenusOS

Item {
	id: gauges

	property alias model: arcRepeater.model
	readonly property real strokeWidth: Theme.geometry_circularMultiGauge_strokeWidth
	required property bool animationEnabled
	property real labelMargin
	property alias labelOpacity: textCol.opacity
	property int leftGaugeCount
	property real longCaptionWidth: width
	property real shortCaptionWidth: width / 2

	// Step change in the size of the bounding boxes of successive gauges
	readonly property real _stepSize: 2 * (strokeWidth + Theme.geometry_circularMultiGauge_spacing)

	Item {
		id: antialiased
		anchors.fill: parent

		// Antialiasing without requiring multisample framebuffers.
		layer.enabled: !UiConfig.msaaEnabled
		layer.smooth: true
		layer.textureSize: Qt.size(antialiased.width*2, antialiased.height*2)

		Repeater {
			id: arcRepeater
			width: parent.width
			delegate: Loader {
				id: loader
				property int gaugeStatus: Theme.getValueStatus(model.level, model.valueType)
				property real level: model.level // always draw the tank level (percentage).
				width: parent.width - (index*_stepSize)
				height: width
				anchors.centerIn: parent
				sourceComponent: model.tankType === VenusOS.Tank_Type_Battery ? shinyProgressArc : progressArc
				onStatusChanged: if (status === Loader.Error) console.warn("Unable to load circular multi gauge progress arc")

				Component {
					id: shinyProgressArc
					ShinyProgressArc {
						radius: width/2
						startAngle: 0
						endAngle: 270
						value: loader.level
						progressColor: Theme.color_darkOk,Theme.statusColorValue(loader.gaugeStatus)
						remainderColor: Theme.color_darkOk,Theme.statusColorValue(loader.gaugeStatus, true)
						strokeWidth: gauges.strokeWidth
						animationEnabled: gauges.animationEnabled
						shineAnimationEnabled: Global.system.battery.mode === VenusOS.Battery_Mode_Charging
					}
				}

				Component {
					id: progressArc
					ProgressArc {
						radius: width/2
						startAngle: 0
						endAngle: 270
						value: loader.level
						progressColor: Theme.color_darkOk,Theme.statusColorValue(loader.gaugeStatus)
						remainderColor: Theme.color_darkOk,Theme.statusColorValue(loader.gaugeStatus, true)
						strokeWidth: gauges.strokeWidth
						animationEnabled: gauges.animationEnabled
					}
				}
			}
		}
	}

	Item {
		id: textCol

		anchors.top: parent.top
		anchors.topMargin: strokeWidth/2
		anchors.bottom: parent.verticalCenter
		anchors.left: parent.left
		anchors.right: parent.horizontalCenter
		anchors.rightMargin: Theme.geometry_circularMultiGauge_icon_rightMargin + gauges.labelMargin

		Repeater {
			model: gauges.model
			delegate: Row {
				anchors.verticalCenter: textCol.top
				anchors.verticalCenterOffset: index * _stepSize/2
				anchors.right: parent.right

				// With three gauges on the left there is a risk that the last labels on
				// on the multi-gauge overlap with the labels on the top-left gauge.
				//
				// Increase the space for the two top-most labels or if there are less left gauges.
				width: (model.index < 2 || gauges.leftGaugeCount < 3 ? gauges.longCaptionWidth : gauges.shortCaptionWidth)
				height: iconImage.height

				Label {
					anchors.verticalCenter: parent.verticalCenter
					rightPadding: Theme.geometry_circularMultiGauge_label_rightMargin
					horizontalAlignment: Text.AlignRight
					font.pixelSize: valueLabel.visible
							? valueLabel.font.pixelSize
							: Theme.font_circularMultiGauge_label_largeSize
					color: Theme.color_font_primary
					text: model.name
					width: parent.width - valueLabel.width - iconImage.width
					elide: Text.ElideRight
				}

				Label {
					id: valueLabel
					anchors.verticalCenter: parent.verticalCenter
					rightPadding: Theme.geometry_circularMultiGauge_value_rightMargin
					horizontalAlignment: Text.AlignRight
					font.pixelSize: Theme.font_circularMultiGauge_label_smallSize
					color: Theme.color_font_primary
					visible: false

					property int unit
					property quantityInfo quantity

					states: State {
						when: Global.systemSettings.briefView.unit.value !== VenusOS.BriefView_Unit_None
						PropertyChanges {
							target: valueLabel

							visible: true
							text: quantity.number + quantity.unit
							quantity: Units.getDisplayText(unit, value)
							unit: {
								if (Global.systemSettings.briefView.unit.value === VenusOS.BriefView_Unit_Percentage) {
									return VenusOS.Units_Percentage
								} else if (model.tankType === VenusOS.Tank_Type_Battery) {
									return VenusOS.Units_Percentage
								} else {
									return Global.systemSettings.volumeUnit
								}
							}
						}
					}
				}

				CP.ColorImage {
					id: iconImage
					source: model.icon
					color: Theme.color_font_primary
					sourceSize: Qt.size(Theme.geometry_circularMultiGauge_icon_size, Theme.geometry_circularMultiGauge_icon_size)
				}
			}
		}
	}
}
