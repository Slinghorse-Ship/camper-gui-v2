/*
** Copyright (C) 2023 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import Victron.VenusOS

GeneratorDialog {
	id: root

	//% "Start Now"
	acceptText: qsTrId("controlcard_generator_startdialog_start_now")
	secondaryTitle: CommonWords.manual_start

	onGeneratorRunningByChanged: {
		if (root.open) {
			if (generatorRunningBy == VenusOS.Generators_RunningBy_Manual) {
				root.accept()
			}
		}
	}

	runGeneratorAction: function() {
		root.generator.start(timedRunSwitch.checked ? Utils.composeDuration(timeSelector.hour, timeSelector.minute) : 0)
	}

	contentItem: ModalDialog.FocusableContentItem {
		implicitHeight: contentColumn.implicitHeight

		Column {
			id: contentColumn
			x: Theme.geometry_modalDialog_content_horizontalMargin
			width: parent.width - (2 * Theme.geometry_modalDialog_content_horizontalMargin)
			spacing: Theme.geometry_modalDialog_content_spacing

			Row {
				anchors {
					left: timeSelector.left
					right: timeSelector.right
				}
				topPadding: Theme.geometry_modalDialog_content_spacing

				Label {
					id: timedRunLabel
					//% "Timed run"
					text: qsTrId("controlcard_generator_startdialog_timed_run")
					width: parent.width - timedRunSwitch.width
					rightPadding: Theme.geometry_listItem_content_spacing
					elide: Text.ElideRight
				}

				Switch {
					id: timedRunSwitch

					checked: root.generator.manualStartTimer > 0
					checkable: true
					focus: true

					// Include label in the navigation highlight
					KeyNavigationHighlight.leftMargin: -timedRunLabel.width - Theme.geometry_listItem_content_spacing
					KeyNavigation.down: timeSelector
				}
			}

			TimeSelector {
				id: timeSelector

				anchors.horizontalCenter: parent.horizontalCenter
				enabled: timedRunSwitch.checked
				maximumHour: 59

				KeyNavigation.down: root.footer
			}

			Label {
				anchors {
					left: parent.left
					right: parent.right
				}
				wrapMode: Text.Wrap
				color: Theme.color_font_primary
				horizontalAlignment: Text.AlignHCenter
				font.pixelSize: Theme.font_dialog_body_size
				text: timedRunSwitch.checked && (timeSelector.hour || timeSelector.minute)
					  ? //% "Generator will stop in %1 unless autostart conditions are enabled that keep it running."
						qsTrId("generator_start_dialog_will_stop_in_x").arg(Utils.formatHoursMinutes(timeSelector.hour, timeSelector.minute))
					  : //% "Generator will run until manually stopped, unless autostart conditions are enabled that keep it running."
						qsTrId("generator_start_dialog_will_run_until_manually_stopped")
			}
		}
	}

	onAboutToShow: {
		const timeParts = Utils.decomposeDuration(root.generator.manualStartTimer)
		timeSelector.hour = timeParts.h
		timeSelector.minute = timeParts.m
	}
}
