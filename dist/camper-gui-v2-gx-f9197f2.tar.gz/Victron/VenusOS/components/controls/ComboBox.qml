/*
** Copyright (C) 2023 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import QtQuick.Templates as T
import QtQuick.Controls.impl as CP
import Victron.VenusOS

T.ComboBox {
	id: root

	property real defaultBackgroundWidth: Theme.geometry_comboBox_width
	property real defaultBackgroundHeight: Theme.geometry_button_height

	// When the ComboBox is focused and the popup is closed, the user can scroll through the options
	// by pressing:
	// - left/right, if keyNavigationDirection=Qt.Vertical
	// - up/down, if keyNavigationDirection=Qt.Horizontal
	// When the popup is open, only the up/down keys will scroll through the popup options, as the
	// list always has a vertical orientation.
	property int keyNavigationDirection: Qt.Vertical

	function _acceptEvent(event, direction, key) {
		if (popup.opened) {
			event.accepted = false
			return
		}
		event.accepted = keyNavigationDirection === direction
		if (event.accepted) {
			if (key === Qt.Key_Forward) {
				incrementCurrentIndex()
			} else {
				decrementCurrentIndex()
			}
		}
		return event.accepted
	}

	implicitWidth: Math.max(
		implicitBackgroundWidth + leftInset + rightInset,
		implicitContentWidth + leftPadding + rightPadding)
	implicitHeight: Math.max(
		implicitBackgroundHeight + topInset + bottomInset,
		implicitContentHeight + topPadding + bottomPadding)

	leftPadding: Theme.geometry_comboBox_leftPadding
	rightPadding: Theme.geometry_comboBox_rightPadding
	topPadding: Theme.geometry_comboBox_verticalPadding
	bottomPadding: Theme.geometry_comboBox_verticalPadding
	spacing: Theme.geometry_comboBox_spacing

	delegate: T.ItemDelegate {
		id: optionDelegate

		width: root.width
		implicitWidth: implicitContentWidth
		implicitHeight: implicitContentHeight
		highlighted: root.highlightedIndex === index || pressed

		contentItem: Rectangle {
			implicitWidth: Theme.geometry_comboBox_width
			implicitHeight: Theme.geometry_button_height
			topLeftRadius: index === 0 ? Theme.geometry_button_radius : 0
			topRightRadius: index === 0 ? Theme.geometry_button_radius : 0
			bottomLeftRadius: index === root.count - 1 ? Theme.geometry_button_radius : 0
			bottomRightRadius: index === root.count - 1 ? Theme.geometry_button_radius : 0
			color: optionDelegate.highlighted ? Theme.color_ok : "transparent"

			Label {
				anchors.fill: parent
				leftPadding: Theme.geometry_comboBox_leftPadding
				rightPadding: Theme.geometry_comboBox_leftPadding  // no indicator here, use same padding as left side
				font.pixelSize: Theme.font_button_size
				verticalAlignment: Text.AlignVCenter
				elide: Text.ElideRight
				text: modelData.text
				color: optionDelegate.highlighted ? Theme.color_button_down_text : Theme.color_font_primary
			}
		}

		KeyNavigationHighlight.active: ListView.isCurrentItem
	}

	indicator: CP.ColorImage {
		id: downIcon

		x: root.width - width - root.rightPadding
		y: root.topPadding + (root.availableHeight - height) / 2
		source: "qrc:/images/icon_chevron_up_32.svg"
		rotation: keyNavigationDirection === Qt.Horizontal ? 90 : 180
		color: root.enabled
			   ? (root.pressed ? Theme.color_primary : Theme.color_ok)
			   : Theme.color_font_disabled
	}

	contentItem: Label {
		leftPadding: 0
		rightPadding: root.indicator.width + root.spacing
		font.pixelSize: Theme.font_button_size
		verticalAlignment: Text.AlignVCenter
		elide: Text.ElideRight
		text: root.displayText
		color: root.enabled
			   ? (root.pressed ? Theme.color_button_down_text : Theme.color_font_primary)
			   : Theme.color_font_disabled
	}

	background: Rectangle {
		implicitWidth: root.defaultBackgroundWidth
		implicitHeight: root.defaultBackgroundHeight
		border.color: root.enabled ? Theme.color_ok : Theme.color_font_disabled
		border.width: Theme.geometry_button_border_width
		radius: Theme.geometry_button_radius
		color: root.enabled
			   ? (root.pressed ? Theme.color_ok : Theme.color_darkOk)
			   : Theme.color_background_disabled
	}

	popup: T.Popup {
		x: root.leftInset
		width: root.width
		height: Math.min(contentItem.implicitHeight, Global.mainView.height - (2 * Theme.geometry_comboBox_verticalPadding))

		contentItem: ListView {
			clip: true
			implicitHeight: contentHeight
			boundsBehavior: Flickable.StopAtBounds
			model: root.popup.visible ? root.delegateModel : null
			currentIndex: root.highlightedIndex

			ScrollBar.vertical: ScrollBar {
				topPadding: Theme.geometry_comboBox_verticalPadding
				bottomPadding: Theme.geometry_comboBox_verticalPadding
			}
		}

		background: Rectangle {
			// This base rectangle is required because the inner rect below has a transparent
			// background (Theme.color_darkOk).
			border.color: Theme.color_ok
			border.width: Theme.geometry_button_border_width
			radius: Theme.geometry_button_radius
			color: Theme.color_page_background

			Rectangle {
				anchors.fill: parent
				radius: Theme.geometry_button_radius
				border.width: Theme.geometry_button_border_width
				border.color: Theme.color_ok
				color: Theme.color_darkOk
			}
		}

		onAboutToShow: {
			// Prefer to show popup in a position where the current selection is shown over the top
			// of the combo box.
			y = root.topInset - (root.currentIndex * root.defaultBackgroundHeight) + Theme.geometry_button_border_width

			// If the popup would be shown with the top edge above the top of the main view, move
			// it downwards.
			const posInWindow = mapToItem(Global.mainView, 0, y)
			if (posInWindow.y < Theme.geometry_comboBox_verticalPadding) {
				y = mapFromItem(Global.mainView, 0, Theme.geometry_comboBox_verticalPadding).y
			}
		}
	}

	Keys.enabled: Global.keyNavigationEnabled
	Keys.onUpPressed: (event) => _acceptEvent(event, Qt.Vertical, Qt.Key_Back)
	Keys.onDownPressed: (event) => _acceptEvent(event, Qt.Vertical, Qt.Key_Forward)
	Keys.onLeftPressed: (event) => _acceptEvent(event, Qt.Horizontal, Qt.Key_Back)
	Keys.onRightPressed: (event) => _acceptEvent(event, Qt.Horizontal, Qt.Key_Forward)

	KeyNavigationHighlight.active: root.activeFocus
	KeyNavigationHighlight.topMargin: root.topInset
	KeyNavigationHighlight.bottomMargin: root.bottomInset
	KeyNavigationHighlight.leftMargin: root.leftInset
	KeyNavigationHighlight.rightMargin: root.rightInset
}
