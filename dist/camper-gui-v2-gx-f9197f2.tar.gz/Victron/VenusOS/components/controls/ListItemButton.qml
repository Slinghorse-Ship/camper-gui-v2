/*
** Copyright (C) 2023 Victron Energy B.V.
** See LICENSE.txt for license information.
*/

import QtQuick
import Victron.VenusOS

Button {
	leftPadding: Theme.geometry_listItemButton_horizontalPadding
	rightPadding: Theme.geometry_listItemButton_horizontalPadding
	font.pixelSize: Theme.font_listItem_secondary_size
	flat: false
}
